package com.example.ecoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class proyectos_registrados : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_proyectos_registrados)
    }
}