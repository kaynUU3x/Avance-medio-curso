package com.example.ecoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class entrar_proyecto : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entrar_proyecto)
    }
}